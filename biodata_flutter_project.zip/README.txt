Proyek Flutter Biodata Mahasiswa.

APK belum dibuat di dalam ZIP ini. Untuk membuat APK:
1. Upload isi proyek ke repository GitHub.
2. Buka tab Actions dan jalankan workflow Build APK.
3. Setelah berhasil, unduh artifact biodata-mahasiswa-apk.
4. Ekstrak ZIP artifact untuk memperoleh app-release.apk.
