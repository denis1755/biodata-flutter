import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Biodata Mahasiswa',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Biodata Mahasiswa'),
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
        ),
        body: Center(
          child: Card(
            margin: const EdgeInsets.all(20),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.person, size: 80, color: Colors.blue),
                  SizedBox(height: 20),
                  Text('BIODATA MAHASISWA',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  Text('Nama: Denis'),
                  Text('Program Studi: Ilmu Komputer'),
                  Text('Universitas: Bumigora'),
                  Text('Semester: 1'),
                  Text('Hobi: Bermain game'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
